#include <iostream>
#include <cstdio>
#include <map>
#include <cmath>
#include <set>
#include <queue>
#include <algorithm>
#include <string>
#include <vector>
#include <cstdlib>
using namespace std;

int n ;
int state ;
int elite_cnt ;
int tri_fea ;
int status_fea;
int homophily_fea ;
int balance_fea ;
int max_d;//48 * 8 * 2 * 8;

// the number of the seeds
int ss_cnt ;
// running cascading times
int R ;


char *graph_path;// "graph_cb.txt";
char *model_path;//= "em_pro_train.txt";
char *outpath;// "follow_cascade.txt";
//char *fbpath ="../fb_pro_cb.txt";

// limit the target user as those with at least 75 followers
const int candidate_limit = 75;
// the number of the tried target users
const int test_time = 5;

struct edge {
	int v, ts;
};
struct wedge {
	int v, st;
	double w;
};
map<int, int> id_map;
vector<edge> *gf, *gb;
int **bif, **bib;
vector<wedge> *fb;
// g record all the neighbors(wedge) for each node
wedge **g;
// d record the degree for each node, fa record all the potential followers for each node
int *d, *fa;
double *greedy_s, *random_s, *greedy2_s, *greedy3_s, *greedy4_s, *greedy5_s;

bool *mark, *is_seed;
double fb_rate;
double *ke,*gv;
int dim;
int *elite;
// user id map
map<int, int> usermap;

void initialize() {
	greedy_s = new double [ss_cnt+1];
	random_s = new double [ss_cnt+1];
	greedy2_s = new double [ss_cnt+1];
	greedy3_s = new double [ss_cnt+1];
	greedy4_s = new double [ss_cnt+1];
	greedy5_s = new double [ss_cnt+1];


	gf = new vector<edge>[n];
	gb = new vector<edge>[n];

	g = new wedge *[n];
	fb = new vector<wedge> [n];

	bif = new int *[n];
	bib = new int *[n];

	elite = new int[n];
	mark = new bool[n];
	is_seed = new bool[n];

    dim = 1;
	if (tri_fea) dim *= state;
    if (status_fea) dim *= 8;
    if (homophily_fea) dim *= 8;
    if (balance_fea) dim *= 2;
    max_d = dim;

    ke = new double[max_d];
    gv = new double[max_d];
}

void load_user_list() {
	FILE *fin = fopen("user_list.txt", "r");
	int id;
	for (int i = 0; i < n; i++) {
		fscanf(fin, "%d\n", &id);
		id_map[id] = i;
	}
	fclose(fin);
}

// load graph data from file, each line in the file should be :
//   x y t
//  which means x follows y at time t. x and y are the user ids, t is the time stamp.
void load_graph_data() {
	FILE *fin = fopen(graph_path, "r");
	int x, y, ts;
	edge e;
	// x: source user, y: target user, ts: x followed y at time ts
	while (fscanf(fin, "%d %d %d\n", &x, &y, &ts) > 0) {
		usermap[x] = 1;
		usermap[y] = 1;
	}
	fclose(fin);

	map<int,int>::iterator uiter ;
	int max_user_id = -1;
	for (uiter=usermap.begin(); uiter!=usermap.end(); uiter++){
		if(uiter->first > max_user_id){
			max_user_id = uiter->first;
		}
	}
	printf("maximal user id = %d\n", max_user_id);
	n = max_user_id;

	initialize();


	fin = fopen(graph_path, "r");
	while (fscanf(fin, "%d %d %d\n", &x, &y, &ts) > 0) {
		e.v = y; e.ts = ts;
		gf[x].push_back(e);
		e.v = x;
		gb[y].push_back(e);
	}
	fclose(fin);
}

inline int find_map(int &val) {
	map<int, int>::iterator cur = id_map.find(val);
	if (cur != id_map.end())
		return cur->second;
	else return -1;
}

inline bool cmp(const edge &e1, const edge &e2) {
	return e1.v < e2.v;
}

inline int find_list(vector<edge> &list, int cnt, int v) {
	int le = 0, ri = cnt - 1, mid;
	while (le <= ri) {
		mid = (le + ri) >> 1;
		if (list[mid].v == v) return mid;
		if (list[mid].v < v)
			le = mid + 1;
		else ri = mid - 1;
	}
	return -1;
}


inline bool cmp_idg(const int &v0, const int &v1) {
    return gb[v0].size() > gb[v1].size();
}

void preprocess() {
	for (int i = 0; i < n; i++) {
		sort(gf[i].begin(), gf[i].end(), cmp);
		sort(gb[i].begin(), gb[i].end(), cmp);
		bif[i] = new int[gf[i].size()];
		for (int j = 0; j < gf[i].size(); j++) {
			bif[i][j] = find_list(gb[i], gb[i].size(), gf[i][j].v);
			if (bif[i][j] >= 0)
				bif[i][j] = gb[i][bif[i][j]].ts;
		}

		bib[i] = new int[gb[i].size()];
		for (int j = 0; j < gb[i].size(); j++) {
			bib[i][j] = find_list(gf[i], gf[i].size(), gb[i][j].v);
			if (bib[i][j] >= 0)
				bib[i][j] = gf[i][bib[i][j]].ts;
		}
	}

    //mark elite users
    int *ind = new int[n];
    for (int i = 0; i < n; i++) ind[i] = i;
    sort(ind, ind + n, cmp_idg);
    for (int i = 0; i < elite_cnt; i++) elite[ind[i]] = 1;
    delete ind;
}

inline int get_status(int a, int b, int c) {
    return (elite[a] << 2) + (elite[b] << 1) + elite[c];
}

inline int exist_common_friend(int a, int b) {
    for (int i = 0; i < gf[a].size(); i++)
        if (gf[a][i].ts == 1 && bif[a][i] == 1) {
            int p = find_list(gf[b], gf[b].size(), gf[a][i].v);
            if (p >= 0 && gf[b][p].ts == 1 && bif[b][p] == 1)
                return 1;
        }
    return 0;
}

inline int get_homophily(int a, int b, int c) {
    return (exist_common_friend(a, b) << 2) + (exist_common_friend(a, c) << 1) + exist_common_friend(b, c);
}

inline int get_balance(int a, int b, int c) {
    int p = find_list(gf[a], gf[a].size(), b);
    /*
    if (p >= 0 && gf[a][p].ts == 1 && bif[a][p] == 1) {
        p = find_list(gf[a], gf[a].size(), c);
        if (p >= 0 && gf[a][p].ts == 1 && bif[a][p] == 1) {
            p = find_list(gf[c], gf[c].size(), b);
            if (p >= 0 && gf[c][p].ts == 1)
                return 1;
        }
    }
    */
    if (p >= 0 && bif[a][p] > 0) {
        p = find_list(gf[a], gf[a].size(), c);
        if (p >= 0 && bif[a][p] > 0) {
            p = find_list(gf[c], gf[c].size(), b);
            if (p >= 0 && gf[c][p].ts == 1)
                return 1;
        }
    }
    return 0;
}


int get_feature(int a, int b, int c, int state) {
    int fx = 0;
    int base = 1;
    if (tri_fea) {
        fx = fx + (state - 1) * base;
        base *= 48;
    }
    if (status_fea) {
        fx = fx + get_status(a, b, c) * base;
        base *= 8;
    }
    if (homophily_fea) {
        fx = fx + get_homophily(a, b, c) * base;
        base *= 8;
    }
    if (balance_fea) {
        fx = fx + get_balance(a, b, c) * base;
        base *= 2;
    }
    return fx;
}

void load_model() {
	printf("model path = %s\n", model_path);
    FILE *fin = fopen(model_path, "r");
    int x, y;
    double val;
    //fscanf(fin, "%d %d %d %d", &x, &x, &x, &x);
    printf("dim = %d\n", dim);
    for (int i = 0; i < dim; i++) {
    	fscanf(fin, "%lf %lf %d %d", ke + i, gv +i, &x, &y);
        //printf("%.9lf %d %d\n", ke[i], x, y);
    }
    fclose(fin);
}


/*
void load_followback_pro() {
	FILE *fin = fopen(fbpath, "r");
	int x, y;
	double w;
	wedge tedge;
	while (fscanf(fin, "%d %d %lf", &x, &y, &w) > 0) {
		tedge.v = y;        
		tedge.w = 1.0;//w;
		fb[x].push_back(tedge);
	}	
	fclose(fin);
}
*/


int get_rand() {
	return ((rand() & 32767) << 15) + (rand() & 32767);
}

void gen_graph(int u) {
	memset(d, 0, sizeof(d));
    int fx, st;
	for (int i = 0; i < n; i++) {
		// if ith user has already followed u, then ignore her
		if (i == u || find_list(gf[i], gf[i].size(), u) >= 0) continue;
		// check each "following" relationship of the ith user
		for (int j = 0; j < gf[i].size(); j++) {
			int v = gf[i][j].v;
			// if v has already followed u, then ignore her
			if (v == u || find_list(gf[v], gf[v].size(), u) >= 0) continue;
			// i->v has a reversed relationship v->i
			if (find_list(gb[i], gb[i].size(), v) >= 0) {
				g[i][d[i]].v = v;                                
                g[i][d[i]].st = 9;
                // u has followed v before
                if (find_list(gf[u], gf[u].size(), v) >= 0) g[i][d[i]].st += 24;
				g[i][d[i]++].w = ke[get_feature(i, v, u, g[i][d[i]].st)];
			// i->v has no reversed relationship v->i
			} else {
				g[i][d[i]].v = v;                
				g[i][d[i]].st = 4;
				if (find_list(gf[u], gf[u].size(), v) >= 0) g[i][d[i]].st += 24;
				g[i][d[i]++].w = ke[get_feature(i, v, u, g[i][d[i]].st)];
			}
		}
		// check each follower of the ith user
		for (int j = 0; j < gb[i].size(); j++) {
			int v = gb[i][j].v;
			// if v has already followed u, then ignore her
			if (v == u || find_list(gf[v], gf[v].size(), u) >= 0) continue;
			// v->i
			if (find_list(gf[i], gf[i].size(), v) < 0) {
				g[i][d[i]].v = v;
				g[i][d[i]].st = 1;
				if (find_list(gf[u], gf[u].size(), v) >= 0) g[i][d[i]].st += 24;
				g[i][d[i]++].w = ke[get_feature(i, v, u, g[i][d[i]].st)];
			}
		}
	}
}

double simulate(int u, double cp) {
	vector<int> list;
	double ret = 0;

	// run R times and calculate the average number of the activated users
	for (int r = 0; r < R; r++) {
		// list record all the activated users by u
		list.clear();
		list.push_back(u);
		mark[u] = true;
		fa[u] = -1;

		// check each activated user v (active means v follows u)
		for (int i = 0; i < list.size(); i++) {
			int v = list[i];
			double pro;
			// check each jth neighbor of v
			for (int j = 0; j < d[v]; j++) {
				pro = g[v][j].w;
                if (v != u && cp >= 0) pro = cp;
                /*
				if (fa[v] == u) {
					if (g[v][j].st == 9) pro = ps[23];
					if (g[v][j].st == 4) pro = ps[12];
					if (g[v][j].st == 1) pro = ps[14];
				}
                */
                // if the jth neighbor is inactive, then toss a coin to determine whether she will be activated.
				if (!mark[g[v][j].v] && (double)rand() / RAND_MAX <= pro) {
					mark[g[v][j].v] = true;
					list.push_back(g[v][j].v);
					// the father of the jth neighbor is v
					fa[g[v][j].v] = v;
				}
			}
		}
		// ret is total number of the activated users for R times,
		ret += list.size() - 1;
		// reset variable mark
		for (int i = 0; i < list.size(); i++) mark[list[i]] = false;
	}
	// return the average number for R times
	return ret / R;
}

double simulate(int u) {
    return simulate(u, -1);
}

// given a seed u, to simulate how many users can be influenced by u
double try_seed(int u, int p) {
	g[u][d[u]++] = fb[u][p];
    //g[u][d[u]] = fb[u][p];
    //g[u][d[u]++].w = 1;//np;
	double ret = simulate(u, -1);
	d[u]--;
	return ret;
}

double try_seed(int u, int p, double np, double cp) {
	g[u][d[u]] = fb[u][p];
    g[u][d[u]++].w = np;
	double ret = simulate(u, cp);
	d[u]--;
	return ret;
}

double try_seed(int u, int p, double np) {	
	return try_seed(u, p, np, -1);
}

void greedy_select_all(int u) {
	priority_queue<pair<double, pair<int, int> > > q;
    fb[u].clear();
    wedge we;
    // find all the users who have not followed u and put them into fb[u], we assume the seed user will follow u with probability 1
    for (int i = 0; i < n; i++) 
        if (i != n && find_list(gf[i], gf[i].size(), u) < 0) {
            we.w = 1; we.v = i;            
            fb[u].push_back(we);
        }
    // calculate the number of users influenced by each user in fb[u]
	for (int i = 0; i < fb[u].size(); i++) {
		pair<int, int> tp = make_pair(i, 1);
		double val = try_seed(u, i);
		q.push(make_pair(val, tp));		
	}    
    
	double ret = 0;
	// select ss_cnt seeds as the users in fb[u] who can activate maximal users.
	// calculate how many users will be influenced by the ss_cnt seeds
	for (int ss = 1; ss <= ss_cnt; ss++) {
		while (1) {
			pair<double, pair<int, int> > tp = q.top();
			q.pop();
			// if the the newly tried user produces the largest increment, then add it into the final seed set.
			if (tp.second.second == ss) {
				ret += tp.first;
				greedy_s[ss] += ret;
				g[u][d[u]++] = fb[u][tp.second.first];
				break;
			// else add the user who can produce the largest increment into the try set, and calculate the increment.
			} else {
				double val = try_seed(u, tp.second.first);
				tp.second.second = ss;
				tp.first = val - ret; // increment when adding current user
				q.push(tp);
			}
		}
	}
	d[u] = 0;
}

//influence maximization assuming every seed will be activated with a probability the same as the follow back probability
// if it's selected.
void greedy_select(int u) {
	priority_queue<pair<double, pair<int, int> > > q;
	for (int i = 0; i < fb[u].size(); i++) {
		pair<int, int> tp = make_pair(i, 1);
		double val = try_seed(u, i);
		q.push(make_pair(val, tp));		
	}
	double ret = 0;
	for (int ss = 1; ss <= ss_cnt; ss++) {
		while (1) {
			pair<double, pair<int, int> > tp = q.top();
			q.pop();
			if (tp.second.second == ss) {
				ret += tp.first;
				greedy_s[ss] += ret;
				g[u][d[u]++] = fb[u][tp.second.first];
				break;
			} else {
				double val = try_seed(u, tp.second.first);
				tp.second.second = ss;
				tp.first = val - ret;
				q.push(tp);
			}
		}
	}
	d[u] = 0;
}
// randomly select seeds
void random_select(int u) {
	int *ind = new int[fb[u].size()];
	for (int i = 0; i < fb[u].size(); i++) {
		ind[i] = i;
		swap(ind[i], ind[get_rand() % (i + 1)]);
	}
	for (int ss = 1; ss <= ss_cnt; ss++) {
		g[u][d[u]++] = fb[u][ind[ss - 1]];
		double val = simulate(u);
		random_s[ss] += val;
	}
	d[u] = 0;
	delete ind;
}

//every time select the node with the biggest followback probability
void greedy2_select(int u) {
	vector<pair<double, int> > list;
	for (int i = 0; i < fb[u].size(); i++) {
		list.push_back(make_pair(-fb[u][i].w, i));
	}
	sort(list.begin(), list.end());
	for (int ss = 1; ss <= ss_cnt; ss++) {
		g[u][d[u]++] = fb[u][list[ss - 1].second];
		double val = simulate(u);
		greedy2_s[ss] += val;
	}
	d[u] = 0;
}

//influence maximization assuming that every seed will be activated if it's selected.
void greedy3_select(int u) {
    priority_queue<pair<double, pair<int, int> > > q;
	for (int i = 0; i < fb[u].size(); i++) {
		pair<int, int> tp = make_pair(i, 1);
		double val = try_seed(u, i, 1.0);
		q.push(make_pair(val, tp));		
	}
	double ret = 0;
    vector<int> seed_list;
	for (int ss = 1; ss <= ss_cnt; ss++) {
		while (1) {
			pair<double, pair<int, int> > tp = q.top();
			q.pop();
			if (tp.second.second == ss) {
				ret += tp.first;				
                seed_list.push_back(tp.second.first);
				g[u][d[u]] = fb[u][tp.second.first];
                g[u][d[u]++].w = 1;
				break;
			} else {
				double val = try_seed(u, tp.second.first, 1.0);
				tp.second.second = ss;
				tp.first = val - ret;
				q.push(tp);
			}
		}
	}
    for (int ss = 1; ss <= ss_cnt; ss++) {
        d[u] = ss;        
        g[u][ss - 1] = fb[u][seed_list[ss - 1]];        
        greedy3_s[ss] += simulate(u);
    }        
	d[u] = 0;    
}

//influence maximization assuming that the follow influence probability is a constant
void greedy4_select(int u) {
    priority_queue<pair<double, pair<int, int> > > q;
    double c_pro = 0.01;
	for (int i = 0; i < fb[u].size(); i++) {
		pair<int, int> tp = make_pair(i, 1);
		double val = try_seed(u, i, 1.0, c_pro);
		q.push(make_pair(val, tp));		
	}
	double ret = 0;
    vector<int> seed_list;
	for (int ss = 1; ss <= ss_cnt; ss++) {
		while (1) {
			pair<double, pair<int, int> > tp = q.top();
			q.pop();
			if (tp.second.second == ss) {
				ret += tp.first;				
                seed_list.push_back(tp.second.first);
				g[u][d[u]] = fb[u][tp.second.first];
                g[u][d[u]++].w = 1;
				break;
			} else {
				double val = try_seed(u, tp.second.first, 1.0, c_pro);
				tp.second.second = ss;
				tp.first = val - ret;
				q.push(tp);
			}
		}
	}
    for (int ss = 1; ss <= ss_cnt; ss++) {
        d[u] = ss;        
        g[u][ss - 1] = fb[u][seed_list[ss - 1]];        
        greedy4_s[ss] += simulate(u, -1);
    }        
	d[u] = 0;
}

//every time select the node with the biggest in-degree
void greedy5_select(int u) {
	vector<pair<double, int> > list; // record degree for each node
	for (int i = 0; i < fb[u].size(); i++) {
        //list.push_back(make_pair(-gb[fb[u][i].v].size(), i));
        list.push_back(make_pair(-(int)gb[fb[u][i].v].size()-(int)gf[fb[u][i].v].size(), i));
	}
	sort(list.begin(), list.end());
	for (int ss = 1; ss <= ss_cnt; ss++) {
		g[u][d[u]++] = fb[u][list[ss - 1].second];
		double val = simulate(u);
		greedy5_s[ss] += val;
	}
	d[u] = 0;
}

// Target: given a target user u, find K seeds to follow u to maximize the followers of u influenced the K seeds.
void follow_cascade() {
	printf("test time=%d\n", n);
	for (int i = 0; i < n; i++) {
		int len = max((int)max(fb[i].size(), gf[i].size() + gb[i].size()), ss_cnt + 10);
		//printf("len=%d\n", len);
		g[i] = new wedge[len];
	}
	// randomly select "test_time" target users
	for (int t = 0; t < test_time; t++) {
		printf("testing %d user...\n", t + 1);
		// randomly select a user u whose potential followers are larger than "candidate_limit"
		int u;
		do {
			u = get_rand() % n;
		} while (fb[u].size() <= candidate_limit);
		// for all the users do not follow u, construct their neighbor potential triads.
		gen_graph(u);
		printf("gen graph done\n");
		// set influence as that learned by FCM and each step select a seed that can influence maximal users
		greedy_select_all(u);
		printf("greedy select done\n");
		// randomly select seeds
		random_select(u); // randomly
		printf("random select done\n");
		//greedy2_select(u);
		//printf("greedy2 select done\n");
        //greedy3_select(u);
        //printf("greedy3 select done\n");
		// set influence uniformly and each step select a seed that can infuence maximal users
        greedy4_select(u); //
        printf("greedy4 select done\n");
        // select seeds as those with greatest degree
        greedy5_select(u);
        printf("greedy5 select done\n");
        fb_rate += gb[u].size() / (gf[u].size() + 1);
	}
    fb_rate /= test_time;
	for (int i = 1; i <= ss_cnt; i++) {
		greedy_s[i] /= test_time;
		random_s[i] /= test_time;
		//greedy2_s[i] /= test_time;
        //greedy3_s[i] /= test_time;
        greedy4_s[i] /= test_time;
        greedy5_s[i] /= test_time;
	}
}

void print() {
	FILE *fout = fopen(outpath, "w");
	//fprintf(fout, "greedy, greedy2, greedy3, random\n");
    fprintf(fout, "greedy, random, greedy4, greedy5\n");
	for (int i = 1; i <= ss_cnt; i++)
		fprintf(fout, "%3.9lf %3.9lf %3.9lf %3.9lf\n", greedy_s[i], random_s[i], greedy4_s[i], greedy5_s[i]);
    fprintf(fout, "average follower / followee: %.9lf\n", fb_rate);
	fclose(fout);
}
int loadConfig(int argc, char* argv[])
{
    if (argc < 7 ) return 0;
    int i = 1;
    while (i < argc)
    {
        if (strcmp(argv[i], "-graphfile") == 0)  // required
        {
           	graph_path = argv[++i]; ++ i;
        }
        else if (strcmp(argv[i], "-modelfile") == 0) // required
        {
        	model_path = argv[++i]; ++i;
        }
        else if (strcmp(argv[i], "-cascadeoutput") == 0) // required
        {
            outpath = argv[++i]; ++i;
        }
        else if (strcmp(argv[i], "-seed_num") == 0) // required
        {
        	ss_cnt = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-cascade_times") == 0) // required
        {
            R = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-triadnum") == 0)
        {
        	state = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-elitecount") == 0)
        {
        	elite_cnt = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-triadfeature") == 0)
        {
        	tri_fea = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-statusfeature") == 0)
        {
        	status_fea = atoi(argv[++i]); ++ i;
        }
        else if (strcmp(argv[i], "-homophilyfeature") == 0)
        {
        	homophily_fea = atoi(argv[++i]); ++ i;
        }
        else if (strcmp(argv[i], "-balancefeature") == 0)
        {
        	balance_fea = atoi(argv[++i]); ++ i;
        }

        else ++ i;
    }
    return 1;
}

void showUsage()
{
    printf("Follower maximization                                            \n");
    printf("     by Zhanpeng Fang, Tsinghua University                     \n");
    printf("                                                             \n");
    printf("Usage: follower_maximization -graphfile GRAPHFILE -modelfile MODELFILE -cascadefile CASCADEFILE [options]         \n");
    printf(" Options:                                                    \n");
    printf("   -seed_num int         : number of the selected seeds                              \n");
    printf("   -cascade_num int      : running cascading times    \n");
    printf("   -triadnum int         : number of triad structures                              \n");
    printf("   -elitecount int       : sort users by the number of followers, then view the top 'elitecount' users as the elite users               \n");
    printf("   -triadfeature int     : consider triad structure as feature or not, 1:yes, 0:no      \n");
    printf("   -statusfeature int    : consider social structure as feature or not, 1:yes, 0:no                   \n");
    printf("   -homophilyfeature int : consider homophily as feature or not, 1:yes, 0:no   \n");
    printf("   -balancefeature  int  : consider social balance as feature or not, 1:yes, 0:no              \n");

    exit( 0 );
}

void setDefault(){
	state = 24;
	elite_cnt = 1000;
	tri_fea = 1;
	status_fea = 0;
	homophily_fea = 0;
	balance_fea = 0;
	ss_cnt = 50;
	R = 10000;

}


int main(int argc, char* argv[]) {

	setDefault();
	printf("set default value for parameters done\n");
	if (! loadConfig(argc, argv))
	{
		showUsage();
	    exit( 0 );
	}
	printf("load configuration done\n");
	load_graph_data();
	printf("load data done\n");
	preprocess();
	printf("preprocess done\n");
	//load_followback_pro();
	//printf("load followback probabilities done\n");
    load_model();
    printf("load model done\n");
	follow_cascade();
	printf("calculate follow cascade done\n");
	print();
	printf("print file done\n");
}
