1."following" infuence learning
====Introduction====
Given a dynamic social network with the formation time of each edge, learn the influence of the formation of one "following" relationship on its neighbor relationship in each kind of triad structure. 
Please refer to Table 1 in the attached paper for "following" influence of 24 triad structures.

======Input=========
Dynamic graph file with each line as follows:
x y t
which indicates that x follows y at time t

======Output========
influence score for each triad structure.

======Code explanation========
1) run FCM/tri_instance_gen.cpp to generate instances from the input dynamic graph.
2) run FCM/tri_instance_spliter.cpp to split instances into training and test set.
3) run FCM/tri_em_train.cpp to learn the influence score for each triad structure.
4) run FCM/tri_em_evaluator.cpp to evaluate the link prediction performance on test set. 


2. follower/followee influence maximization
====Introduction====
Given a social network, and the influence between each two "following" relationships in a triad structure, to estimate the maximal activacted follower/followees to a targert user (can be selected randomly for several times) by selecting K seed users.

======Input=========
1) Graph file with each line as follows:
x y
which indicates that x follows y. 

2) Seed number K.
3) Influence score for each triad structure.

======Output========
The expected maximal number of followers/followees to a target user influenced by K selected seed users.

======Code explanation========
1) run influence_maximization/follow_cascade_new to estimate maximal number of followers to a target user influenced by K selected seed followers.
2) run influence_maximization/rec_cascade_new to to estimate maximal number of followees to a target user influenced by K selected seed followees.



3. Data
We crawled a twitter dataset. To begin the collection process, we selected the most popular user on Twitter, i.e., “Lady Gaga”, and randomly collected 10,000 of her followers. We took
these users as seed users and used a crawler to collect all followers of these users by traversing “following” relationships. We continue the traversing process, which produced in total 13,442,659 users and 56,893,234 “following” relationships, with an average of 728,509 new relationships per day. The crawler monitored the change of the network structure from 10/12/2010 to 12/23/2010. 
From the data we extract a complete subnetwork, in which relationships between all users are recorded. The complete subnetwork consists of 112,044 users and 468,238 “following” relationships between them.

The dynamic graph is in:
data/graph_cb.txt 

