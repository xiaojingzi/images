#include <iostream>
#include <cstdio>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <vector>
using namespace std;

int gap_limit = 7;
int max_d ;
double threshold = 0.08;
int tri_fea = 1;
int status_fea = 0;
int homophily_fea = 0;
int balance_fea = 0;
char *outpath;
char *test_file_path ;
char *model_path;
char *predpath ;

struct edge {
	int v, ts;
};

struct TriVal {
	int tri, t;
	double va, vb, vx, vy, vp;
	
	TriVal() {
		tri = t = 0;
	}
	
	TriVal(int tri_, int t_): tri(tri_), t(t_) {}
};

int *ca3, *cs3;
map<pair<int, int>, vector<TriVal> > TP, TN;
int te;
double *ke, *gv;
int dim;

void initialize() {
    dim = 1;
	if (tri_fea) dim *= 25;
    if (status_fea) dim *= 8;
    if (homophily_fea) dim *= 8;
    if (balance_fea) dim *= 2;

    max_d = dim;
	ca3 = new int[max_d];
	cs3 = new int[max_d];
	ke = new double[max_d];
	gv = new double[max_d];
}



void load_test_instance() {
    int tot;
    FILE *fin = fopen(test_file_path, "r");
    int mode;
    fscanf(fin, "%d %d\n", &tot, &mode);
    char ch;
    int cn, val, v1, v2;
    int u, v;
    vector<TriVal> tv;
    for (int i = 0; i < tot; i++) {
        if (mode == 0) {
            fscanf(fin, "%c %d", &ch, &cn);
        } else if (mode == 1) {
            fscanf(fin, "%c %d %d %d", &ch, &u, &v, &cn);        
        }
        tv.clear();
        for (int j = 0; j < cn; j++) {
            fscanf(fin, "%d %d", &v1, &v2);
            tv.push_back(TriVal(v1, v2));
            ca3[v1]++;
            if (ch == '+') cs3[v1]++;
        }
        if (ch == '+') {
            TP[make_pair(i, i)] = tv;
        } else {
            TN[make_pair(i, i)] = tv;
        }
        fscanf(fin, "\n");
    }
    fclose(fin);
}

void load_model() {
    FILE *fin = fopen(model_path, "r");
    int x, y;
    double val;
    fscanf(fin, "%d %d %d %d", &x, &x, &x, &x);
    for (int i = 0; i < dim; i++) {
        fscanf(fin, "%lf %lf %d %d", ke + i, gv + i, &x, &y);
    }
    fclose(fin);
}

double fgv[25][100];
double get_pro(vector<TriVal> &tv) {
    double ret = 1;
    for (int i = 0; i < tv.size(); i++) 
		ret *= ke[tv[i].tri] * fgv[tv[i].tri][tv[i].t] + (1 - ke[tv[i].tri]);
    return 1 - ret;
}

double get_pro3(vector<TriVal> &tv) {
    double ret = 1;
    for (int i = 0; i < tv.size(); i++) {
		ret *= ke[tv[i].tri] * fgv[tv[i].tri][gap_limit + 1] + (1 - ke[tv[i].tri]);		
	}
    return 1 - ret;
}

double get_pro2(vector<TriVal> &tv) {
	double ret = 1, tval = 1;
	for (int i = 0; i < tv.size(); i++) {
		TriVal &tri = tv[i];
		ret *= (ke[tri.tri] * gv[tri.tri] * fgv[tri.tri][tri.t - 1] 
			+ ke[tri.tri] * fgv[tri.tri][tri.t] + (1 - ke[tri.tri]));
		tval *= ke[tri.tri] * fgv[tri.tri][tri.t] + (1 - ke[tri.tri]);
	}
	return ret - tval;
}

void evaluate_result() {
	for (int i = 0; i < dim; i++) {
		fgv[i][0] = 1;		
		for (int j = 1; j <= gap_limit + 1; j++) fgv[i][j]= fgv[i][j - 1] * (1 - gv[i]);
	}
    map<pair<int, int>, vector<TriVal> >::iterator miter;    
    FILE *fout = fopen(predpath, "w");
    int acc, match, lab, plab;
    acc = match = plab = 0;
    for (miter = TP.begin(); miter != TP.end(); miter++) {
        double val = get_pro3(miter->second);
        fprintf(fout, "%.9lf\n", val);
        lab = val >= threshold ? 1 : 0;
        if (lab == 1) {
            acc++;
            match++;
            plab++;
        }
    }
    for (miter = TN.begin(); miter != TN.end(); miter++) {
        double val = get_pro(miter->second);
        fprintf(fout, "%.9lf\n", val);
        lab = val >= threshold ? 1 : 0;
        if (lab == 1) {
            plab++;
        } else {
            acc++;
        }
    }
    fclose(fout);
    double prec = (double)match / (plab > 0 ? plab : 1);
    double recall = (double)match / (TP.size() > 0 ? TP.size() : 1);
    double f1 = 2 * prec * recall / (prec + recall);
    fout = fopen(outpath, "w");
    /*
    fprintf(fout, "accuracy: %.9lf\n", (double)acc / (TP.size() + TN.size()));
    fprintf(fout, "precision: %.9lf\n", prec);
    fprintf(fout, "recall: %.9lf\n", recall);
    fprintf(fout, "F1 score: %.9lf\n", f1);
    */
    fprintf(fout, "%.9lf\n", (double)acc / (TP.size() + TN.size())); //accuracy
    fprintf(fout, "%.9lf\n", prec); // precision
    fprintf(fout, "%.9lf\n", recall); // recall
    fprintf(fout, "%.9lf\n", f1); // F1 score
    fclose(fout);
}


int loadConfig(int argc, char* argv[])
{
    if (argc < 9 ) return 0;
    int i = 1;
    while (i < argc)
    {
        if (strcmp(argv[i], "-testfile") == 0)  // required
        {
        	test_file_path = argv[++i]; ++ i;
        }
        else if (strcmp(argv[i], "-modelfile") == 0)  // required
        {
        	model_path = argv[++i]; ++ i;
        }
        else if (strcmp(argv[i], "-predfile") == 0) // required
        {
        	predpath = argv[++i]; ++i;
        }
        else if (strcmp(argv[i], "-evalfile") == 0) // required
        {
        	outpath = argv[++i]; ++i;
        }
        else if (strcmp(argv[i], "-threshold") == 0)
        {
        	threshold = atof(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-timegap") == 0)
        {
        	gap_limit = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-triadfeature") == 0)
        {
        	tri_fea = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-statusfeature") == 0)
        {
        	status_fea = atoi(argv[++i]); ++ i;
        }
        else if (strcmp(argv[i], "-homophilyfeature") == 0)
        {
        	homophily_fea = atoi(argv[++i]); ++ i;
        }
        else if (strcmp(argv[i], "-balancefeature") == 0)
        {
        	balance_fea = atoi(argv[++i]); ++ i;
        }
        else ++ i;
    }
    return 1;
}

void setDefault(){
	gap_limit = 7;
	tri_fea = 1;
	status_fea = 0;
	homophily_fea = 0;
	balance_fea = 0;
	threshold = 0.08;

}

void showUsage()
{
    printf("Following Cascade Model - EM algorithm for learning the influence of triad structures                                \n");
    printf("     by Zhanpeng Fang, Tsinghua University                     \n");
    printf("                                                             \n");
    printf("Usage: tri_em_evaluator -testfile TESTFILE -modelfile MODELFILE -predfile PREDFILE -evalfile EVALFILE [options]         \n");
    printf(" Options:                                                    \n");
    printf("   -threshold double             : the threshold for determining whether one edge is formed or not      \n");
    printf("   -timegap int                  : the maximal time slot between the influencing edge and the influenced edge         \n");
    printf("   -triadfeature int             : consider triad structure as feature or not, 1:yes, 0:no      \n");
    printf("   -statusfeature int            : consider social structure as feature or not, 1:yes, 0:no                   \n");
    printf("   -homophilyfeature int         : consider homophily as feature or not, 1:yes, 0:no   \n");
    printf("   -balancefeature  int          : consider social balance as feature or not, 1:yes, 0:no              \n");

    exit( 0 );
}

int main(int argc, char* argv[]) {

	setDefault();
	printf("set default value for parameters done\n");
	if (! loadConfig(argc, argv))
	{
		showUsage();
	    exit( 0 );
	}
	printf("load configuration done\n");
	initialize();
	printf("initialization done\n");
	load_test_instance();
    printf("load train instance done\n");
    load_model();
    printf("load model done\n");
    evaluate_result();
    printf("evaluate result done\n");
	
}
