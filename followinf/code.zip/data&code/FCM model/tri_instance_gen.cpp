#include <iostream>
#include <cstdio>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <vector>
using namespace std;

// required parameters
 char *graph_path ;
 char *outpath ;
 // optional parameters
 int state ;
 int log_cnt ;
 int elite_cnt ;
 int gap_limit ;
 int tri_fea ;
 int status_fea ;
 int homophily_fea ;
 int balance_fea ;


const int pm[] = {0, 1, 25, 26, 2, 13, 14, 37, 38, 3, 27, 28, 5, 39, 4, 17, 29, 16, 15, 40, 41, 18, 42,
 6, 30, 7, 31, 32, 8, 19, 20, 43, 44, 9, 33, 34, 11, 45, 10, 23, 35, 22, 21, 46, 47, 24, 48, 12, 36}; 
//const int max_buf = 65536;
//const int max_id = 205773762;
//const int max_t = 100;
//const int max_d = 48 * 8 * 2 * 8;

struct edge {
	int v, ts;
};

struct TriVal {
	int tri, t;
	double va, vb, vx, vy, vp;
	
	TriVal() {
		tri = t = 0;
	}
	
	TriVal(int tri_, int t_): tri(tri_), t(t_) {}
};

// each element denotes a user v and the users v follows
vector<edge> *gf;
// each element denotes a user v and the users being followed by v
vector<edge> *gb;
int **bif, **bib;
// each element denotes a pair of neighbor edges, with multiple triad structures as features.
map<pair<int, int>, vector<TriVal> > TP, TN;
int dim;
int *elite;
// user id map
map<int, int> usermap;
// the number of users
int n ;


//char buf[max_buf];
//map<int, int> id_map;
//int timestamp;
//int ol[n];
//int ca[state * 2], cs[state * 2], ca2[state * 2], cs2[state * 2];
//int ca3[max_d], cs3[max_d];
//int te;
//double ke[max_d], ke_2[max_d];


void setDefault(){
	state = 24;
	log_cnt = 10000;
	elite_cnt = 1000;
	gap_limit = 7;
	tri_fea = 1;
	status_fea = 0;
	homophily_fea = 0;
	balance_fea = 0;
}

void initialize() {

	gf = new vector<edge>[n];
	gb = new vector<edge>[n];

	bif = new int *[n];
	bib = new int *[n];

	elite = new int[n];

    dim = 1;
	if (tri_fea) dim *= 25;
    if (status_fea) dim *= 8;
    if (homophily_fea) dim *= 8;
    if (balance_fea) dim *= 2;
}

/*
void load_user_list() {
	FILE *fin = fopen("user_list.txt", "r");
	int id;
	for (int i = 0; i < n; i++) {
		fscanf(fin, "%d\n", &id);
		id_map[id] = i;
	}
	fclose(fin);
}

inline int find_map(int &val) {
	map<int, int>::iterator cur = id_map.find(val);
	if (cur != id_map.end())
		return cur->second;
	else return -1;
}
*/

inline bool cmp(const edge &e1, const edge &e2) {
	return e1.v < e2.v;
}

inline int find_list(vector<edge> &list, int cnt, int v) {
	int le = 0, ri = cnt - 1, mid;
	while (le <= ri) {
		mid = (le + ri) >> 1;
		if (list[mid].v == v) return mid;
		if (list[mid].v < v)
			le = mid + 1;
		else ri = mid - 1;
	}
	return -1;
}


inline bool cmp_idg(const int &v0, const int &v1) {
    return gb[v0].size() > gb[v1].size();
}

// use gf to save the following relationships, gb to save the follower relationships
// bif to save the reversed relationships corresponding to gf
// bib to save the reversed relationships corresponding to bf
void preprocess() {
	for (int i = 0; i < n; i++) {
		// sort the followings of the ith user by the user id
		sort(gf[i].begin(), gf[i].end(), cmp);
		// sort the followers of the ith user by the user id
		sort(gb[i].begin(), gb[i].end(), cmp);

		// bif and bib are for easy use later
		// bif[i][j] saves the formation time of the edge j->i. j->i is the reversed edge of i->j.
		bif[i] = new int[gf[i].size()];
		for (int j = 0; j < gf[i].size(); j++) {
			bif[i][j] = find_list(gb[i], gb[i].size(), gf[i][j].v);
			if (bif[i][j] >= 0)
				bif[i][j] = gb[i][bif[i][j]].ts;
		}
			
		// bib[i][j] saves the formation time of the edge i->j. i->j is the reversed edge of j->i.
		bib[i] = new int[gb[i].size()];
		for (int j = 0; j < gb[i].size(); j++) {
			bib[i][j] = find_list(gf[i], gf[i].size(), gb[i][j].v);
			if (bib[i][j] >= 0)
				bib[i][j] = gf[i][bib[i][j]].ts;
		}
	}	
    
    //mark elite users, 1 means elite user
    int *ind = new int[n];
    for (int i = 0; i < n; i++) ind[i] = i;
    sort(ind, ind + n, cmp_idg);
    for (int i = 0; i < elite_cnt; i++) elite[ind[i]] = 1;
    delete ind;
}
// status of (a,b,c) : 000,001,010,011,100, 101, 110,111
inline int get_status(int a, int b, int c) {
    return (elite[a] << 2) + (elite[b] << 1) + elite[c];
}

// check whether a and b has common friends ( two users with reciprocal relationships are called friends)
inline int exist_common_friend(int a, int b) {
    for (int i = 0; i < gf[a].size(); i++)
        if (gf[a][i].ts == 1 && bif[a][i] == 1) {
            int p = find_list(gf[b], gf[b].size(), gf[a][i].v);
            if (p >= 0 && gf[b][p].ts == 1 && bif[b][p] == 1)
                return 1;
        }
    return 0;
}

// homophily of (a, b, c): 000,001,010,011,100, 101, 110,111, 0 means has common friends, 1 means has no common friends
inline int get_homophily(int a, int b, int c) {
    return (exist_common_friend(a, b) << 2) + (exist_common_friend(a, c) << 1) + exist_common_friend(b, c);
}

// check whether triad (a, b, c) is balanced. Balance means there are reciprocal relationships among a, b and c.
inline int get_balance(int a, int b, int c) {
    int p = find_list(gf[a], gf[a].size(), b);
    /*
    if (p >= 0 && gf[a][p].ts == 1 && bif[a][p] == 1) {
        p = find_list(gf[a], gf[a].size(), c);
        if (p >= 0 && gf[a][p].ts == 1 && bif[a][p] == 1) {
            p = find_list(gf[c], gf[c].size(), b);
            if (p >= 0 && gf[c][p].ts == 1)
                return 1;
        }
    }
    */
    if (p >= 0 && bif[a][p] > 0) {
        p = find_list(gf[a], gf[a].size(), c);
        if (p >= 0 && bif[a][p] > 0) {
            p = find_list(gf[c], gf[c].size(), b);
            if (p >= 0 && gf[c][p].ts == 1)
                return 1;
        }
    }
    return 0;
}

// calculate the feature index for triad instance (a, b, c)
// the feature can be basic triad structure, status, homophily, or balance
int get_feature(int a, int b, int c, int state) {
    int fx = 0;
    int base = 1;
    if (tri_fea) {
        fx = fx + (state - 1) * base;
        base *= 48;        
    }
    if (status_fea) {
        fx = fx + get_status(a, b, c) * base;
        base *= 8;
    }
    if (homophily_fea) {
        fx = fx + get_homophily(a, b, c) * base;
        base *= 8;
    }
    if (balance_fea) {
        fx = fx + get_balance(a, b, c) * base;
        base *= 2;
    }

    return fx;
}

// update positive/negative instances belong to a given triad structure.
int tot, vw;
void update(int s, int ts, int u, int v, int ts_lim) {
	tot++;
	//cout << "here " << s << " " << ts << " " << u << " " << v << " " << gf[u].size() << endl;
	// find the position of v in u's following list
	int p = find_list(gf[u], gf[u].size(), v);
	// find the position of v in u's follower list
	int pb = find_list(gb[u], gb[u].size(), v);    	 
	// ignore the situation that there is a reversed edge v->u that formed a short time before edge u->v
    if (pb >= 0 && gb[u][pb].ts > 1 && (p < 0 || gb[u][pb].ts <= gf[u][p].ts)) return;
    // ignore the situation that there is an additional edge in the triad which was formed between ts and gf[u][p]
    if (ts_lim >= 0 && p >= 0 && gf[u][p].ts >= ts_lim) return;
	//cout << "here1" << endl;
    /*
	if (p < 0 || p >= 0 && gf[u][p].ts > ts && (pb < 0 || gb[u][pb].ts > gf[u][p].ts)) {
		ca[s]++;
		if (p >= 0) cs[s]++;
	}
    */
    


	if (p < 0 || p >= 0 && gf[u][p].ts >= ts) {  
		// if u->v has a pre-existing reversed edge, then triad type plus 24
        if (pb >= 0 && gb[u][pb].ts == 1) s += 24;
		s = pm[s];
		if (s > 24) return;
        /* 
		ca2[s]++;
		if (p >= 0) cs2[s]++;
        */
        int fx = get_feature(vw, u, v, s);               
        
        // ca3 saves the number of positive and negative instances containing the feature fx
		//ca3[fx]++;
		// cs3 saves the number of positive instances containing the feature fx
		//if (p >= 0 && gf[u][p].ts - ts <= gap_limit) cs3[fx]++;
		
        if (p >= 0 && gf[u][p].ts - ts <= gap_limit) {
        	// positive instances
            TP[make_pair(u, v)].push_back(TriVal(fx, gf[u][p].ts - ts + 1));
        } else {
        	//�negative instances
            TN[make_pair(u, v)].push_back(TriVal(fx, gap_limit + 1));
        }
	}
	//cout << "here2" << endl;
}

inline int get_limit(int v0, int v1) {
    if (v0 < 0) return v1;
    else if (v1 < 0) return v0;
    else return min(v0, v1);
}

// count the number of instances belonging to 48 triad structures, and save all the instances
// positive instance: with the potential edge added within limited time
// negative instance: with the potential edge not added within limited time
void count_state() {
	for (int i = 0; i < n; i++) {
	
		if (i % log_cnt == 0) printf("count state %d\n", i);
		//printf("i: %d\n", i);
        vw = i;
        // The follower diffusion category
		for (int j = 0; j < gf[i].size(); j++) {
			// the ith user and her jth friend, u is user id of her jth friend
			int u = gf[i][j].v;
			// t is the time the ith user follows u
			int t = gf[i][j].ts;
			// t==1 denotes that the formation time of the edge is not collected
            if (t == 1) continue;
            // for one edge i->j without reversed edge j<-i
			if (bif[i][j] < 0 || bif[i][j] > t) {

				// for the edge k->i with/without reversed edge i->k
				for (int k = 0; k < gb[i].size(); k++) {
					//if (gb[i][k].ts >= t) continue;
                    if (gb[i][k].ts > 1) continue;
					int v = gb[i][k].v;
					// for the edge k->i without reversed edge i->k
					if (bib[i][k] < 0 || bib[i][k] > t) { 
						update(1, t, v, u, get_limit(bib[i][k], bif[i][j]));   // edge k->j
						update(7, t, u, v, get_limit(bib[i][k], bif[i][j]));   // edge j->k
					// for the edge k->i with reversed edge i->k
					} else {
						if (bib[i][k] > 1) continue;
						update(9, t, v, u, bif[i][j]);   //edge k->j
						update(20, t, u, v, bif[i][j]);  //edge j->k
					}					
				}
				// for the edge i->k without reversed edge k->i
				for (int k = 0; k < gf[i].size(); k++) {
					if (gf[i][k].ts > 1) continue;
					int v = gf[i][k].v;
					if (bif[i][k] < 0 || bif[i][k] > t) {
						update(4, t, v, u, get_limit(bif[i][k], bif[i][j]));  // edge k->j
						update(8, t, u, v, get_limit(bif[i][k], bif[i][j]));  // edge j->k
					}
				}
			// for one edge i->j with reversed edge j->i
			} else {
				if (bif[i][j] > 1) continue;
				// for the edge k->i with/without reversed edge i->k
				for (int k = 0; k < gb[i].size(); k++) {
					if (gb[i][k].ts > 1) continue;
					int v = gb[i][k].v;
					// for the edge k->i without reversed edge i->k
					if (bib[i][k] < 0 || bib[i][k] > t) { 
						update(14, t, v, u, bib[i][k]);
						update(19, t, u, v, bib[i][k]);
					// for the edge k->i with reversed edge i->k
					} else {
						if (bib[i][k] > 1) continue;
						update(23, t, v, u, -1);
						update(22, t, u, v, -1);
					}					
				}
				// for the edge i->k without reversed edge k->i
				for (int k = 0; k < gf[i].size(); k++) {
					if (gf[i][k].ts > 1) continue;
					int v = gf[i][k].v;
					if (bif[i][k] < 0 || bif[i][k] > t) {
						update(12, t, v, u, bif[i][k]);
						update(13, t, u, v, bif[i][k]);
					}
				}
			}
		}
		
		// The followee diffusion category
		for (int j = 0; j < gb[i].size(); j++) {
			int u = gb[i][j].v;
			int t = gb[i][j].ts;
            if (t == 1) continue;
            // for one edge j->i without reversed edge j<-i
			if (bib[i][j] < 0 || bib[i][j] > t) {
				for (int k = 0; k < gb[i].size(); k++) {
					if (gb[i][k].ts > 1) continue;
					int v = gb[i][k].v;
					// for the edge k->i without reversed edge i->k
					if (bib[i][k] < 0 || bib[i][k] > t) { 
						update(2, t, v, u, get_limit(bib[i][j], bib[i][k]));
						update(6, t, u, v, get_limit(bib[i][j], bib[i][k]));
					// for the edge k->i with reversed edge i->k
					} else {
						if (bib[i][k] > 1) continue;
						update(11, t, v, u, bib[i][j]);
						update(18, t, u, v, bib[i][j]);
					}					
				}
				// for the edge i->k without reversed edge k->i
				for (int k = 0; k < gf[i].size(); k++) {
					if (gf[i][k].ts > 1) continue;
					int v = gf[i][k].v;
					if (bif[i][k] < 0 || bif[i][k] > t) {
						update(3, t, v, u, get_limit(bib[i][j], bif[i][k]));
						update(5, t, u, v, get_limit(bib[i][j], bif[i][k]));
					}
				}
			// for one edge j->i with reversed edge j<-i
			} else {
				if (bib[i][j] > 1) continue;
				for (int k = 0; k < gb[i].size(); k++) {
					if (gb[i][k].ts > 1) continue;
					int v = gb[i][k].v;
					// for the edge k->i without reversed edge i->k
					if (bib[i][k] < 0 || bib[i][k] > t) { 
						update(10, t, v, u, bib[i][k]);
						update(15, t, u, v, bib[i][k]);
					// for the edge k->i with reversed edge i->k
					} else {
						if (bib[i][k] > 1) continue;
						update(24, t, v, u, -1);
						update(21, t, u, v, -1);
					}					
				}
				// for the edge i->k without reversed edge k->i
				for (int k = 0; k < gf[i].size(); k++) {
					if (gf[i][k].ts > 1) continue;
					int v = gf[i][k].v;
					if (bif[i][k] < 0 || bif[i][k] > t) {
						update(16, t, v, u, bif[i][k]);
						update(17, t, u, v, bif[i][k]);
					}
				}
			}
		}
	}
	cout << "time in update: " << tot << endl;
}

// print instances, with the format of each line as:
// 1. positive/negative edge instance
// 2. the number of triad structures belonging to the instance
// 3. repeated pairs with each as  "triad sturcture id and the time difference between the influencing edge and influenced edge"
void print_instances() {
	map<pair<int, int>, vector<TriVal> >::iterator miter;
	
	// add an additional feature for each instance
//	for (miter = TP.begin(); miter != TP.end(); miter++) {
//		miter->second.push_back(TriVal(24, 1));
//	}
//	for (miter = TN.begin(); miter != TN.end(); miter++) {
//		miter->second.push_back(TriVal(24, 1));
//	}
	
	
    FILE *fout = fopen(outpath, "w");
    // print total number of instances
    fprintf(fout, "%d %d\n", TP.size() + TN.size(), 0);    
    // print positive instances
    for (miter = TP.begin(); miter != TP.end(); miter++) {
    	// print the number of triad structures
        fprintf(fout, "+ %d", miter->second.size());
        // print triad id and value, where value is the time difference between the influencing edge and influenced edge.
        for (int i = 0; i < miter->second.size(); i++)
            fprintf(fout, " %d %d", miter->second[i].tri, miter->second[i].t);
        fprintf(fout, "\n");
    }
    // print negative instances
    for (miter = TN.begin(); miter != TN.end(); miter++) {
        fprintf(fout, "- %d", miter->second.size());
        for (int i = 0; i < miter->second.size(); i++)
            fprintf(fout, " %d %d", miter->second[i].tri, miter->second[i].t);
        fprintf(fout, "\n");
    }    
    fclose(fout);
}

/*
void print_file() {
	FILE *fout = fopen(outpath, "w");
    fprintf(fout, "%d %d %d %d\n", tri_fea, status_fea, homophily_fea, balance_fea);
	for (int i = 0; i < dim; i++) {
        fprintf(fout, "%.9lf %d %d\n", ke[i], cs3[i], ca3[i]);
    }
	fclose(fout);
}


void print_graph() {
	FILE *fout = fopen(graph_path, "w");
	for (int i = 0; i < n; i++)
		for (int j = 0; j < gf[i].size(); j++)
			fprintf(fout, "%d %d %d\n", i, gf[i][j].v, gf[i][j].ts);
	fclose(fout);
}
*/

// load graph data from file, each line in the file should be :
//   x y t
//  which means x follows y at time t. x and y are the user ids, t is the time stamp.
void load_graph_data() {
	FILE *fin = fopen(graph_path, "r");
	int x, y, ts;
	edge e;
	// x: source user, y: target user, ts: x followed y at time ts
	while (fscanf(fin, "%d %d %d\n", &x, &y, &ts) > 0) {
		usermap[x] = 1;
		usermap[y] = 1;
	}
	fclose(fin);

	map<int,int>::iterator uiter ;
	int max_user_id = -1;
	for (uiter=usermap.begin(); uiter!=usermap.end(); uiter++){
		if(uiter->first > max_user_id){
			max_user_id = uiter->first;
		}
	}
	printf("maximal user id = %d\n", max_user_id);
	n = max_user_id;

	initialize();


	fin = fopen(graph_path, "r");
	while (fscanf(fin, "%d %d %d\n", &x, &y, &ts) > 0) {
		e.v = y; e.ts = ts;
		gf[x].push_back(e);
		e.v = x;
		gb[y].push_back(e);
	}
	fclose(fin);
}


int loadConfig(int argc, char* argv[])
{
    if (argc < 5 ) return 0;
    int i = 1;
    while (i < argc)
    {
        if (strcmp(argv[i], "-inputfile") == 0)  // required
        {
           	graph_path = argv[++i]; ++ i;
        }
        else if (strcmp(argv[i], "-outputfile") == 0) // required
        {
            outpath = argv[++i]; ++i;
        }
        else if (strcmp(argv[i], "-triadnum") == 0)
        {
        	state = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-logcount") == 0)
        {
        	log_cnt = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-elitecount") == 0)
        {
        	elite_cnt = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-timegap") == 0)
        {
        	gap_limit = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-triadfeature") == 0)
        {
        	tri_fea = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-statusfeature") == 0)
        {
        	status_fea = atoi(argv[++i]); ++ i;
        }
        else if (strcmp(argv[i], "-homophilyfeature") == 0)
        {
        	homophily_fea = atoi(argv[++i]); ++ i;
        }
        else if (strcmp(argv[i], "-balancefeature") == 0)
        {
        	balance_fea = atoi(argv[++i]); ++ i;
        }

        else ++ i;
    }
    return 1;
}

void showUsage()
{
    printf("Following Cascade Model- count triad structures and generate instances                                             \n");
    printf("     by Zhanpeng Fang, Tsinghua University                     \n");
    printf("                                                             \n");
    printf("Usage: tri_instance_gen -inputfile INPUTFILE -outputfile OUTPUTFILE [options]         \n");
    printf(" Options:                                                    \n");
    printf("   -triadnum int         : number of triad structures                              \n");
    printf("   -logcount int         : record the log whenever processing 'logcount' instances    \n");
    printf("   -elitecount int       : sort users by the number of followers, then view the top 'elitecount' users as the elite users               \n");
    printf("   -timegap int          : the maximal time slot between the influencing edge and the influenced edge                       \n");
    printf("   -triadfeature int     : consider triad structure as feature or not, 1:yes, 0:no      \n");
    printf("   -statusfeature int    : consider social structure as feature or not, 1:yes, 0:no                   \n");
    printf("   -homophilyfeature int : consider homophily as feature or not, 1:yes, 0:no   \n");
    printf("   -balancefeature  int  : consider social balance as feature or not, 1:yes, 0:no              \n");

    exit( 0 );
}


int main(int argc, char* argv[]) {

	setDefault();
	printf("set default value for parameters done\n");
	if (! loadConfig(argc, argv))
	{
		showUsage();
	    exit( 0 );
	}
	printf("load configuration done\n");
	/*
	load_user_list();
	load_data("../data/2010_10_12_new/");
	load_data("../data/2010_10_15_new/");
	load_data("../data/2010_10_17_new/");
	load_data("../data/2010_10_19_new/");
	*/
	load_graph_data();
	printf("load data done\n");

//	print_graph();
	
	preprocess();
	printf("preprocess done\n");
	count_state();
	printf("count state done\n");
    print_instances();
    printf("print instances done\n");
	
}
