#include <iostream>
#include <cstdio>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <vector>
using namespace std;


int max_t;
int max_d;//48 * 8 * 2 * 8;
int gap_limit;
int tri_fea ;
int status_fea ;
int homophily_fea ;
int balance_fea ;
char *outpath ;
char *train_file_path ;

struct edge {
	int v, ts;
};

struct TriVal {
	int tri, t;
	double va, vb, vx, vy, vp;
	
	TriVal() {
		tri = t = 0;
	}
	
	TriVal(int tri_, int t_): tri(tri_), t(t_) {}
};


int *ca3, *cs3;
map<pair<int, int>, vector<TriVal> > TP, TN;
double *ke, *ke_2, *gv, *gu, *gd;
int dim;



void initialize() {

	dim = 1;
	if (tri_fea) dim *= 25;
	if (status_fea) dim *= 8;
	if (homophily_fea) dim *= 8;
	if (balance_fea) dim *= 2;
	max_d = dim;

	ca3 = new int[max_d];
	cs3 = new int[max_d];
	ke = new double[max_d];
	ke_2 = new double[max_d];
	gv = new double[max_d];
	gu = new double[max_d];
	gd = new double[max_d];


}

void load_train_instance() {

    int tot;
    FILE *fin = fopen(train_file_path, "r");
    int mode;
    fscanf(fin, "%d %d\n", &tot, &mode);
    char ch;
    int cn, val, v1, v2;
    int u, v;
    vector<TriVal> tv;
    for (int i = 0; i < tot; i++) {
        if (mode == 0) {
            fscanf(fin, "%c %d", &ch, &cn);        
        } else if (mode == 1) {
            fscanf(fin, "%c %d %d %d", &ch, &u, &v, &cn);        
        }
        tv.clear();
        for (int j = 0; j < cn; j++) {
            fscanf(fin, "%d %d", &v1, &v2);
            tv.push_back(TriVal(v1, v2));
            ca3[v1]++;
            if (ch == '+') cs3[v1]++;
        }
        if (ch == '+') {
            TP[make_pair(i, i)] = tv;
        } else {
            TN[make_pair(i, i)] = tv;
        }
        fscanf(fin, "\n");
    }
    fclose(fin);
}


void EM_alg() {    
	int ml = 0;
	map<pair<int, int>, vector<TriVal> >::iterator miter;
	double pgv[25][100];
	
	for (miter = TP.begin(); miter != TP.end(); miter++) {		
		if (miter->second.size() > ml) ml = miter->second.size();
	}
	for (miter = TN.begin(); miter != TN.end(); miter++) {	
		if (miter->second.size() > ml) ml = miter->second.size();	
	}
	//srand(0);
	for (int i = 0; i < dim; i++) ke[i] = ca3[i] > 0 ? ((double)cs3[i] / ca3[i]) : 0;//(double)rand() / RAND_MAX;//
	double *fv = new double[ml + 10];
	double *bv = new double[ml + 10];
    for (int i = 0; i < dim; i++) gv[i] = 0.001;//(double)rand() / RAND_MAX;;//0.8;
	printf("TP size: %d, TN size: %d\n", TP.size(), TN.size());
    for (int T = 0; T < max_t; T++) {
        printf("Processing iteration %d...\n", T);        		
		//for (int i = 0; i < dim; i++)
		//	printf("tri %d: %.9lf %.9lf\n", i + 1, ke[i], gv[i]);
		double val;
		memset(ke_2, 0, sizeof(ke_2));
		memset(gu, 0, sizeof(gu));
		memset(gd, 0, sizeof(gd));
		memset(pgv, 0, sizeof(pgv));

		// (1-g_{e'e})^{t_e-t_e'}
		for (int i = 0; i < dim; i++) {
			pgv[i][0] = 1;
			for (int j = 1; j <= gap_limit + 1; j++) 
				pgv[i][j] = pgv[i][j - 1] * (1 - gv[i]);
		}
		
        for (miter = TP.begin(); miter != TP.end(); miter++) {
			vector<TriVal> &tv = miter->second;			
			double val = 1;			
			for (int i = 0; i < tv.size(); i++) {
				TriVal &tri = tv[i];
				// x_{e'e}=h_{e'e}g_{e'e}(1-g_{e'e})^{t_e-t_e'}
				tri.vx = ke[tri.tri] * gv[tri.tri] * pgv[tri.tri][tri.t - 1];
				// y_{e'e}=h_{e'e}(1-g_{e'e})^{t_e-t_e'+1}+(1-h_{e'e})
				tri.vy = ke[tri.tri] * pgv[tri.tri][tri.t] + (1 - ke[tri.tri]);				
				fv[i] = i > 0 ? (fv[i - 1] * (tv[i - 1].vx + tv[i - 1].vy)) : 1;
			}
			for (int i = tv.size() - 1; i >= 0; i--) {
				bv[i] = (i == tv.size() - 1) ? 1 : (bv[i + 1] * (tv[i + 1].vx + tv[i + 1].vy));
			}
			double vp = 1;
			for (int i = 0; i < tv.size(); i++) {
				TriVal &tri = tv[i];
				// A_{e'e} = (x_{e'e}\prod_{d \in S_e\e'}(x_{de}+y_{de}))
				tri.va = tri.vx * bv[i] * fv[i];
				// B_{e'e} = (h_{e'e}(1-g_{ee})^{t_e-t_e'})/(h_{e'e}(1-g_{e'e})^{t_e-t_e'}+(1-h_{e'e}))
				tri.vb = ke[tri.tri] * pgv[tri.tri][tri.t] / (ke[tri.tri] * pgv[tri.tri][tri.t] + (1 - ke[tri.tri]));
				vp *= tri.vy;
			}
			// p = 1-\prod_{e' \in S_e}y_{e'e}
			vp = 1 - vp;
			for (int i = 0; i < tv.size(); i++) {
				TriVal &tri = tv[i];
				// D_{e'e}=B_{e'e}+A_{e'e}/p-A_{e'e}/p * B_{e'e}
				// \sum_{(e',e) \in C_tr^+} D_{e'e}
				ke_2[tri.tri] += tri.vb + tri.va / vp - tri.va * tri.vb / vp;
				// \sum_{(e',e) \in C_tr^+} A_{e'e}
				gu[tri.tri] += tri.va / vp;
				// \sum_{(e',e) \in C_tr^+} D_{e'e}*(t_e-t_e'+1)
				gd[tri.tri] += (tri.vb + tri.va / vp - tri.va / vp * tri.vb) * tri.t;
				//printf("TP: %.9lf %.9lf %.9lf\n", ke_2[tri.tri], gu, gd);
				//printf("tri: %d, t: %d, vx: %.9lf, vy: %.9lf, vp: %.9lf, va: %.9lf, vb: %.9lf\n", tri.tri, tri.t, tri.vx, 
				//	tri.vy, vp, tri.va, tri.vb);
				//system("pause");
			}
		}
		
		for (miter = TN.begin(); miter != TN.end(); miter++) {
			vector<TriVal> &tv = miter->second;			
			for (int i = 0; i < tv.size(); i++) {
				TriVal &tri = tv[i];				
				tri.vb = ke[tri.tri] * pgv[tri.tri][tri.t] / (ke[tri.tri] * pgv[tri.tri][tri.t] + (1 - ke[tri.tri]));
				//\sum_{(e',e) \in C_tr^-} B_{e'e}(\delta+1)
				gd[tri.tri] += tri.vb * (gap_limit + 1);
				//\sum_{(e',e) \in C_tr^-} B_{e'e}
				ke_2[tri.tri] += tri.vb;
				//printf("TP: %.9lf %.9lf %.9lf\n", ke_2[tri.tri], gu, gd);
				//system("pause");
			}						
		}
		
		// h_tr = (\sum_{(e',e) \in C_tr^+} D_{e'e} +\sum_{(e',e) \in C_tr^-} B_{e'e}) / |C_tr|
		for (int i = 0; i < dim; i++) ke_2[i] = ca3[i] > 0 ? (ke_2[i] / ca3[i]) : 0;
        memcpy(ke, ke_2, sizeof(ke));        
        //g_tr = \sum_{(e',e) \in C_tr^+} A_{e'e} / (\sum_{(e',e) \in C_tr^-} B_{e'e}(\delta+1)+\sum_{(e',e) \in C_tr^+} D_{e'e}*(t_e-t_e'+1))
		for (int i = 0; i < dim; i++) gv[i] = gd[i] == 0 ? 0 : gu[i] / gd[i];
    }
	
	delete fv;
	delete bv;
}

void print_file() {
	printf("output = %s", outpath);
	FILE *fout = fopen(outpath, "w");
    //fprintf(fout, "%d %d %d %d\n", tri_fea, status_fea, homophily_fea, balance_fea);
	for (int i = 0; i < dim; i++) {
		//printf("%.9lf %.9lf %d %d\n", ke[i], gv[i], cs3[i], ca3[i]);
        fprintf(fout, "%.9lf %.9lf %d %d\n", ke[i], gv[i], cs3[i], ca3[i]);
    }
	fclose(fout);
}



int loadConfig(int argc, char* argv[])
{
    if (argc < 5 ) return 0;
    int i = 1;
    while (i < argc)
    {
        if (strcmp(argv[i], "-trainfile") == 0)  // required
        {
        	train_file_path = argv[++i]; ++ i;
        }
        else if (strcmp(argv[i], "-model") == 0) // required
        {
        	outpath = argv[++i]; ++i;
        }
        else if (strcmp(argv[i], "-niter") == 0)
        {
        	max_t = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-timegap") == 0)
        {
        	gap_limit = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-triadfeature") == 0)
        {
        	tri_fea = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-statusfeature") == 0)
        {
        	status_fea = atoi(argv[++i]); ++ i;
        }
        else if (strcmp(argv[i], "-homophilyfeature") == 0)
        {
        	homophily_fea = atoi(argv[++i]); ++ i;
        }
        else if (strcmp(argv[i], "-balancefeature") == 0)
        {
        	balance_fea = atoi(argv[++i]); ++ i;
        }
        else ++ i;
    }
    return 1;
}

void setDefault(){
	max_t = 8;
	gap_limit = 7;
	tri_fea = 1;
	status_fea = 0;
	homophily_fea = 0;
	balance_fea = 0;

}

void showUsage()
{
    printf("Following Cascade Model - EM algorithm for learning the influence of triad structures                                \n");
    printf("     by Zhanpeng Fang, Tsinghua University                     \n");
    printf("                                                             \n");
    printf("Usage: tri_em_train -trainfile TRAINFILE -model MODELFILE [options]         \n");
    printf(" Options:                                                    \n");
    printf("   -niter     int                : the number of iterations                             \n");
    printf("   -timegap int                  : the maximal time slot between the influencing edge and the influenced edge         \n");
    printf("   -triadfeature int             : consider triad structure as feature or not, 1:yes, 0:no      \n");
    printf("   -statusfeature int            : consider social structure as feature or not, 1:yes, 0:no                   \n");
    printf("   -homophilyfeature int         : consider homophily as feature or not, 1:yes, 0:no   \n");
    printf("   -balancefeature  int          : consider social balance as feature or not, 1:yes, 0:no              \n");

    exit( 0 );
}

int main(int argc, char* argv[]) {
	
	setDefault();
	printf("set default value for parameters done\n");
	if (! loadConfig(argc, argv))
	{
		showUsage();
	    exit( 0 );
	}
	printf("load configuration done\n");
	initialize();
	printf("initialization done\n");

	load_train_instance();
    printf("load train instance done\n");
    EM_alg();
    printf("EM calculation done\n");
	print_file();
	
}
