#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;

char *input_path;
char *train_path ;
char *test_path;
double rate = 0.2;
const int part_const = 0;
int part;
int n;
int mode;
vector<vector<pair<int, int> > > pos, neg;
vector<pair<int, int> > ppa, npa;

inline int get_rand() {
    return (rand() & 32767) + ((rand() & 32767) << 15);
}


int loadConfig(int argc, char* argv[])
{
    if (argc < 7 ) return 0;
    int i = 1;
    while (i < argc)
    {
        if (strcmp(argv[i], "-inputfile") == 0)  // required
        {
        	input_path = argv[++i]; ++ i;
        }
        else if (strcmp(argv[i], "-trainfile") == 0) // required
        {
        	train_path = argv[++i]; ++i;
        }
        else if (strcmp(argv[i], "-testfile") == 0)
        {
        	test_path = argv[++i]; ++i;
        }
        else if (strcmp(argv[i], "-fold") == 0)
        {
        	rate = atoi(argv[++i]); ++i;
        }
        else if (strcmp(argv[i], "-partition") == 0)
        {
        	part = atoi(argv[++i]); ++i;
        }
        else ++ i;
    }
    return 1;
}

void setDefault(){
	rate = 0.2;
	part=part_const;
}

void showUsage()
{
    printf("Following Cascade Model - Split instance file into training and test test                                                \n");
    printf("     by Zhanpeng Fang, Tsinghua University                     \n");
    printf("                                                             \n");
    printf("Usage: tri_instance_spliter -inputfile INPUTFILE -trainfile TRAINFILE -testfile TESTFILE [options]         \n");
    printf(" Options:                                                    \n");
    printf("   -fold     int     : the number of the folds for cross validation                              \n");
    printf("   -partition int    : the partition index to be tested    \n");
    exit( 0 );
}


int main(int argc, char *argv[]) {
	setDefault();
	printf("set default value for parameters done\n");
	if (! loadConfig(argc, argv))
	{
		showUsage();
	    exit( 0 );
	}
	printf("load configuration done\n");
    //srand(time(NULL));


    // read all the instances from file into pos and neg
    FILE *fin = fopen(input_path, "r");    
    fscanf(fin, "%d %d\n", &n, &mode);    
    char ch;
    int val, cn, u, v, v1, v2;    
    vector<pair<int, int> > tv;
    for (int i = 0; i < n; i++) {          
        if (mode == 0) {
            fscanf(fin, "%c %d", &ch, &cn);        
        } else if (mode == 1) {
            fscanf(fin, "%c %d %d %d", &ch, &u, &v, &cn);
        }
        tv.clear();
        for (int j = 0; j < cn; j++) {
            fscanf(fin, "%d %d", &v1, &v2);
            tv.push_back(make_pair(v1, v2));
        }
        fscanf(fin, "\n");
        if (ch == '+') {
            pos.push_back(tv);
            if (mode == 1) ppa.push_back(make_pair(u, v));
        } else {
            neg.push_back(tv);
            if (mode == 1) npa.push_back(make_pair(u, v));
        }
    }    
    fclose(fin);


    // shuffle the index of instances
    vector<int> pp, pn;
    for (int i = 0; i < pos.size(); i++) pp.push_back(i);
    for (int i = 0; i < neg.size(); i++) pn.push_back(i);
    for (int i = 0; i < pp.size(); i++) swap(pp[i], pp[get_rand() % (i + 1)]);
    for (int i = 0; i < pn.size(); i++) swap(pn[i], pn[get_rand() % (i + 1)]);
    //random_shuffle(pp.begin(), pp.end());
    //random_shuffle(pn.begin(), pn.end());

    // get the "part" partition as the test set, where "part" can be 0, 1, 2, 3, 4 where rate=0.2
    int sp = (int)(pos.size() * rate), sn = (int)(neg.size() * rate);
    for (int i = 0; i < sp; i++) swap(pp[i], pp[part * sp + i]);
    for (int i = 0; i < sn; i++) swap(pn[i], pn[part * sp + i]);


    // output test set
    FILE *fout = fopen(test_path, "w");
    fprintf(fout, "%d %d\n", sp + sn, mode);
    for (int i = 0; i < sp; i++) {
        int j = pp[i];
        if (mode == 0) {
            fprintf(fout, "+ %d", pos[j].size());
        } else {
            fprintf(fout, "+ %d %d %d", ppa[j].first, ppa[j].second, pos[j].size());
        }
        for (int k = 0; k < pos[j].size(); k++)
            fprintf(fout, " %d %d", pos[j][k].first, pos[j][k].second);
        fprintf(fout, "\n");
    }    
    for (int i = 0; i < sn; i++) {
        int j = pn[i];
        if (mode == 0) {
            fprintf(fout, "- %d", neg[j].size());
        } else {
            fprintf(fout, "- %d %d %d", npa[j].first, npa[j].second, neg[j].size());
        }
        for (int k = 0; k < neg[j].size(); k++)
            fprintf(fout, " %d %d", neg[j][k].first, neg[j][k].second);
        fprintf(fout, "\n");
    }
    fclose(fout);
    

    // output training set
    fout = fopen(train_path, "w");
    fprintf(fout, "%d %d\n", pos.size() + neg.size() - sp - sn, mode);
    for (int i = sp; i < pos.size(); i++) {
        int j = pp[i];
        if (mode == 0) {
            fprintf(fout, "+ %d", pos[j].size());
        } else {
            fprintf(fout, "+ %d %d %d", ppa[j].first, ppa[j].second, pos[j].size());
        }
        for (int k = 0; k < pos[j].size(); k++)
            fprintf(fout, " %d %d", pos[j][k].first, pos[j][k].second);
        fprintf(fout, "\n");
    }    
    for (int i = sn; i < neg.size(); i++) {
        int j = pn[i];
        if (mode == 0) {
            fprintf(fout, "- %d", neg[j].size());
        } else {
            fprintf(fout, "- %d %d %d", npa[j].first, npa[j].second, neg[j].size());
        }
        for (int k = 0; k < neg[j].size(); k++)
            fprintf(fout, " %d %d", neg[j][k].first, neg[j][k].second);
        fprintf(fout, "\n");
    }
    fclose(fout);
}
